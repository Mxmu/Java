package 第六次上机.第一题;

import 第六次上机.第一题.LinkList;

public class MyTest {
    public static void main(String[] args){
        LinkList mylist=new LinkList();
        mylist.Sort_Create();
    }
}
