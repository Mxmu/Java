package 第六次上机.第一题;

public class LinkNode {
    public int data;
    public LinkNode next;
    LinkNode(int data){
        this.data=data;
    }
    void show(){
        System .out.println(data);
    }
}
