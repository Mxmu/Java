package 第三次上机.第四题;

public class Jc1 {
    void fun(Father1 f1)
    {
        f1.f();
    }
}
