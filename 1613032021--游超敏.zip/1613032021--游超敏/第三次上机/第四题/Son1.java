package 第三次上机.第四题;

//import FatherSon.Father1;

public class Son1 extends Father1 {
    void f()
    {
        System.out.println("this is the son1");
    }
}
