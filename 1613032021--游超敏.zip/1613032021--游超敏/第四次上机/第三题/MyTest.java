package 第四次上机.第三题;

public class MyTest {
    public static void main(String[] args)
    {
        Poststudent p=new Poststudent();
        p.get_Snumber();
        p.get_Class();
        p.get_Wnumber();
        p.get_Salary();
    }
}
