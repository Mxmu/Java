package 第四次上机.第三题;

public interface Teacher {
    void get_Wnumber();
    void get_Salary();
}
