package 第四次上机.第一题;

public class MyTest {
    public static void main(String[] args)
    {
        Bike a=new Bike();
        Car b=new Car();
        Bus c=new Bus();
        a.run();
        a.brake();
        b.run();
        b.brake();
        c.run();
        c.brake();
    }
}
