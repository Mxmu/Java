package 第四次上机.第三题;

public class Poststudent implements Student,Teacher {
    public void get_Snumber()
    {
        System.out.println("查询学号方法");
    }
    public void get_Class()
    {
        System.out.println("查询班级方法");
    }
    public void get_Wnumber()
    {
        System.out.println("查询工号方法");
    }
    public void get_Salary()
    {
        System.out.println("查询工资方法");
    }
}
