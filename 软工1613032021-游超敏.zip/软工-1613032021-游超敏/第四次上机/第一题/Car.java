package 第四次上机.第一题;

public class Car extends TransTool {
    void run()
    {
        System.out.println("Car run");
    }
    void brake()
    {
        System.out.println("Car brake");
    }
}
