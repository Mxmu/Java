package 第四次上机.第一题;

public class Bike extends TransTool {
    void run()
    {
        System.out.println("Bike run");
    }
    void brake()
    {
        System.out.println("Bike brake");
    }
}
