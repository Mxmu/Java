package 第四次上机.第一题;

public class Bus extends TransTool {
    void run()
    {
        System.out.println("Bus run");
    }
    void brake()
    {
        System.out.println("Bus brake");
    }
}
