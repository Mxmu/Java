package 第三次上机.第四题;

public class Son2 extends Father1 {
    void f()
    {
        System.out.println("this is the son2");
    }
}
