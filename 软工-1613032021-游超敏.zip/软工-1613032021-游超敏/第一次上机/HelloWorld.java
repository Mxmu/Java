package 第一次上机;

/**
 * 软件工程161班
 * 1613032021
 * 游超敏
 * 要求：配置环境及运行第一个java程序
 */
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
